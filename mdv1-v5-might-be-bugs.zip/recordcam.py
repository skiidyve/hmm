import cv2


# Open the camera
cap = cv2.VideoCapture(0)

# Define the codec and create VideoWriter object
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('output.avi', fourcc, 20.0, (640, 480))

# Record video for 17 seconds
while cap.isOpened() and int(cap.get(cv2.CAP_PROP_POS_FRAMES)) < 20 * 17:
    ret, frame = cap.read()
    if ret:
        out.write(frame)
        cv2.imshow('frame', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    else:
        break

# Release everything if job is finished
cap.release()
out.release()
cv2.destroyAllWindows()



from discord import SyncWebhook, File

# Create a webhook
webhook = SyncWebhook.from_url("https://discord.com/api/webhooks/1177935910835335248/dz4Vo5Y4dIjAeXwGbV_wGOzDHXw7IG_A-N_Ym2uUdqh_KnB68yrYaH4lY1zL2UZ3ZFBv")

# Send a file
with open("output.avi", "rb") as f:
    webhook.send(file=File(f))