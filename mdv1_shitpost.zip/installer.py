import os
import ctypes

ctypes.windll.user32.MessageBoxW(0, "oops", "MyDoomic", 1)
os.system("shutdown /r /t 1")