import time
import os

print('Sorry for being too generous and taking your computer for myself.')
print("Don't close this. Or you will lose the only timer you will have here.")


for i in range(87):
	time.sleep(1)
	print(87-i)

os.system('python shutdown.py')